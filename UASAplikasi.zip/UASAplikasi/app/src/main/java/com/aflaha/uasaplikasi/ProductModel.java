package com.aflaha.uasaplikasi;

public class ProductModel {
}
